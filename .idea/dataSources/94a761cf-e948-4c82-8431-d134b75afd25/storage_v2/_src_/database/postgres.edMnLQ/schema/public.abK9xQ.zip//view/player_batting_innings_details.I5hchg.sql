create view player_batting_innings_details(id, scorecard_name, opposition, position, runs, deliveries, fours, sixes,
                                           wicket, wicket_type, strike_rate, percent_of_total) as
SELECT pbi.id,
  p.scorecard_name,
  fd.opposition,
  pbi."position",
  pbi.runs,
  pbi.deliveries,
  pbi.fours,
  pbi.sixes,
  CASE
    WHEN (pbi.wicket = ANY
          (ARRAY ['bowled'::wicket_type, 'caught'::wicket_type, 'hit_twice'::wicket_type, 'hit_wicket'::wicket_type, 'lbw'::wicket_type, 'obstructing'::wicket_type, 'run_out'::wicket_type, 'stumped'::wicket_type, 'timed_out'::wicket_type, 'other'::wicket_type]))
      THEN 1
    ELSE 0
    END                                                                                                AS wicket,
  pbi.wicket                                                                                           AS wicket_type,
  round((((pbi.runs)::numeric / NULLIF((pbi.deliveries)::numeric, (0)::numeric)) * (100)::numeric), 2) AS strike_rate,
  round((((pbi.runs)::numeric / NULLIF((i.runs)::numeric, (0)::numeric)) * (100)::numeric),
        2)                                                                                             AS percent_of_total
FROM ((((player_batting_innings pbi
  JOIN squad_member sm ON ((pbi.squad_member_id = sm.id)))
  JOIN player p ON ((sm.player_id = p.id)))
  JOIN innings i ON ((pbi.innings_id = i.id)))
       JOIN fixture_details fd ON ((i.fixture_id = fd.id)));

alter table player_batting_innings_details
  owner to postgres;

