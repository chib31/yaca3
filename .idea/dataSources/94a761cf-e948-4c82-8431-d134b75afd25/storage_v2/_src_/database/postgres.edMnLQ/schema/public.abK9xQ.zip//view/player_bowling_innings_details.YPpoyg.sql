create view player_bowling_innings_details(id, scorecard_name, opposition, date, bowler_number, deliveries, maidens,
                                           runs, wickets, wides, no_balls, hat_tricks, result, economy, over_length) as
SELECT pbi.id,
  p.scorecard_name,
  fd.opposition,
  fd.date,
  pbi.bowler_number,
  pbi.deliveries,
  pbi.maidens,
  pbi.runs,
  pbi.wickets,
  pbi.wides,
  pbi.no_balls,
  pbi.hat_tricks,
  fd.result,
  round(((pbi.runs)::numeric / NULLIF(((pbi.deliveries)::numeric / (6)::numeric), (0)::numeric)), 2) AS economy,
  fd.over_length
FROM ((((player_bowling_innings pbi
  JOIN squad_member sm ON ((pbi.squad_member_id = sm.id)))
  JOIN player p ON ((sm.player_id = p.id)))
  JOIN innings i ON ((pbi.innings_id = i.id)))
       JOIN fixture_details fd ON ((i.fixture_id = fd.id)));

alter table player_bowling_innings_details
  owner to postgres;

