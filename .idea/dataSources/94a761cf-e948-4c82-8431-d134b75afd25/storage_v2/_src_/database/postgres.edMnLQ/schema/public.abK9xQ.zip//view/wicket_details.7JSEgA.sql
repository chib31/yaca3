create view wicket_details(id, date, opposition, wicket_type, bowler, fielder, batting_position, batter_runs) as
SELECT w.id,
  fd.date,
  fd.opposition,
  w.wicket_type,
  pb.scorecard_name AS bowler,
  pf.scorecard_name AS fielder,
  w.batting_position,
  w.batter_runs
FROM ((((((wicket w
  JOIN innings i ON ((w.innings_id = i.id)))
  JOIN fixture_details fd ON ((i.fixture_id = fd.id)))
  LEFT JOIN squad_member smb ON ((w.bowler_id = smb.id)))
  LEFT JOIN squad_member smf ON ((w.fielder_id = smf.id)))
  LEFT JOIN player pb ON ((smb.player_id = pb.id)))
       LEFT JOIN player pf ON ((smf.player_id = pf.id)));

alter table wicket_details
  owner to postgres;

