create view fixture_details(id, date, opposition, location, format, captain, coin_toss, plastics_bat_first,
                            plastics_score, opposition_score, result, result_details, over_length) as
SELECT f.id,
  f.date,
  o.name                                                                            AS opposition,
  f.location,
  concat(((((f.match_type)::text || ' ('::text) || f.innings_length) || ')'::text)) AS format,
  p.scorecard_name                                                                  AS captain,
  CASE
    WHEN (f.win_toss IS TRUE) THEN 'won'::text
    WHEN (f.win_toss IS FALSE) THEN 'lost'::text
    ELSE 'n/a'::text
    END                                                                             AS coin_toss,
  f.bat_first                                                                       AS plastics_bat_first,
  ((pi.runs || ' - '::text) || pi.wickets)                                          AS plastics_score,
  ((oi.runs || ' - '::text) || oi.wickets)                                          AS opposition_score,
  f.result,
  CASE
    WHEN (f.result = 'won'::result_type) THEN
      CASE
        WHEN f.bat_first THEN (('Won by '::text || (pi.runs - oi.runs)) || ' run(s)'::text)
        ELSE (('Won by '::text || (10 - pi.wickets)) || ' wicket(s)'::text)
        END
    WHEN (f.result = 'lost'::result_type) THEN
      CASE
        WHEN f.bat_first THEN (('Lost by '::text || (10 - oi.wickets)) || ' wicket(s)'::text)
        ELSE (('Lost by '::text || (oi.runs - pi.runs)) || ' run(s)'::text)
        END
    WHEN (f.result = 'tied'::result_type) THEN 'Match tied'::text
    WHEN (f.result = 'drawn'::result_type) THEN 'Match drawn'::text
    ELSE 'No result'::text
    END                                                                             AS result_details,
  f.over_length
FROM ((((((fixture f
  JOIN opposition o ON ((f.opposition_id = o.id)))
  JOIN squad_member sm ON (((sm.fixture_id = f.id) AND (sm.captain IS TRUE))))
  JOIN player p ON ((p.id = sm.player_id)))
  JOIN constant c ON ((c.id = 1)))
  JOIN innings pi ON (((pi.fixture_id = f.id) AND (pi.us_batting IS TRUE))))
       JOIN innings oi ON (((oi.fixture_id = f.id) AND (oi.us_batting IS FALSE))));

alter table fixture_details
  owner to postgres;

