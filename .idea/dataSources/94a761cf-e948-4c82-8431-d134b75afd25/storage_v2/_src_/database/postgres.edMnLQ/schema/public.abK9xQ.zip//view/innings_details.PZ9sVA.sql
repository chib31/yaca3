create view innings_details(id, date, innings_order, batting_team, bowling_team, deliveries, wickets, runs, byes,
                            leg_byes, wides, no_balls, total_extras, run_rate) as
SELECT i.id,
  f.date,
  i.innings_order,
  CASE
    WHEN (i.us_batting IS TRUE) THEN c.team_name
    ELSE o.name
    END                                                                                                AS batting_team,
  CASE
    WHEN (i.us_batting IS FALSE) THEN c.team_name
    ELSE o.name
    END                                                                                                AS bowling_team,
  i.deliveries,
  i.wickets,
  i.runs,
  i.byes,
  i.leg_byes,
  i.wides,
  i.no_balls,
  (((COALESCE(i.byes, 0) + COALESCE(i.leg_byes, 0)) + COALESCE(i.wides, 0)) + COALESCE(i.no_balls, 0)) AS total_extras,
  round(((i.runs)::numeric / ((i.deliveries)::numeric / (6)::numeric)), 2)                             AS run_rate
FROM (((innings i
  JOIN fixture f ON ((i.fixture_id = f.id)))
  JOIN opposition o ON ((f.opposition_id = o.id)))
       JOIN constant c ON ((c.id = 1)));

alter table innings_details
  owner to postgres;

