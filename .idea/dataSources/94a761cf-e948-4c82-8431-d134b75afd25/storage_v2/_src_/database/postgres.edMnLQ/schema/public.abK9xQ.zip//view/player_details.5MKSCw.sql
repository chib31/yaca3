create view player_details(id, scorecard_name, cap_number, shirt_number) as
SELECT p.id,
  p.scorecard_name,
  p.cap_number,
  p.shirt_number
FROM player p;

alter table player_details
  owner to postgres;

